//
// Created by Ignacio on 14/4/2022.
//

#ifndef TP1_PRINTEARTABLERO_H
#define TP1_PRINTEARTABLERO_H
#include <string>
#include "structs.h"

void printearEnTxt(Tablero &tablero, std::string rutaSalida, int jugador);

void limpiarEnTxt(Tablero &tablero, std::string rutaSalida, int jugador);

#endif //TP1_PRINTEARTABLERO_H
