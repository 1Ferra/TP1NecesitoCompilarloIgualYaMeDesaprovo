//
// Created by Ignacio on 14/4/2022.
//

#ifndef TP1_CONSTANTES_H
#define TP1_CONSTANTES_H

#define ALTO 10
#define ANCHO 10

#endif //TP1_CONSTANTES_H
